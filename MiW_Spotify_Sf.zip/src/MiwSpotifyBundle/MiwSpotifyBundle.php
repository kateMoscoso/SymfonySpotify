<?php

namespace MiwSpotifyBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MiwSpotifyBundle extends Bundle
{
}
