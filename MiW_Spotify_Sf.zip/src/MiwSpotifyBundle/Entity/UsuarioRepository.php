<?php  // src/MiwSpotifyBundle/Entity/UsuarioRepository.php

namespace MiwSpotifyBundle\Entity;
 
use Doctrine\ORM\EntityRepository;
 
class UsuarioRepository extends EntityRepository
{


}
